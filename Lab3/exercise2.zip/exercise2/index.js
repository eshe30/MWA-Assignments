const fs = require("fs");
const path = require("path");
const http = require("http");

const filePath = path.join(__dirname, "file");

function createServer(task, port, name) {
  http
    .createServer((req, res) => {
      res.writeHead(200, { "Content-Type": "file" });
      watchMem(name);
      task(res);
      watchMem(name);
    })
    .listen(port);
}

//read stream
createServer(
  res => {
    const readStream = fs.createReadStream(filePath);
    readStream.pipe(res);
  },
  4000,
  "Stream"
);

//blocking buffered read
createServer(
  res => res.write(fs.readFileSync(filePath, "utf8")),
  4001,
  "Sync read"
);

//async buffered read
createServer(
  res => fs.readFile(filePath, "utf8", (err, data) => res.write(data)),
  4002,
  "Async read"
);

//helper for logging memory usage
function watchMem(name) {
  const usage = process.memoryUsage();
  console.log(name, {
    rss: Math.floor(usage.rss / 100000),
    heapTotal: Math.floor(usage.heapTotal / 100000),
    heapUsed: Math.floor(usage.heapUsed / 100000)
  });
}
