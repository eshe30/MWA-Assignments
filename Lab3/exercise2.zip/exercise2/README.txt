As shown in memory_usage.png and response_time.png:

     METHOD     | MEMORY USAGE | RESPONSE TIME
---------------------------------------------------
1. readStream   | ~300         | 13ms
2. fileReadSync | ~1800        | ~2.5s
3. fileRead     | ~1800        | ~2.5s

As illustrated above, fileRead and fileReadySync will take much longer response
time because they have to create a buffer size equal to the file sending.
Whereas readStream will only create sufficient (much smaller) buffer and
stream it.
