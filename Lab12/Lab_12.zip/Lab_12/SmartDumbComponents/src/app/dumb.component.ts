import { Component, OnInit , Input} from '@angular/core';

@Component({
  selector: 'app-dumb',
  template: `
    <p>
      dumb works!
    </p>
    <div *ngIf="users; else emptyList>
    <ol>
     <li *ngFor = "let user of users"> {{user.firstName}} {{user.lastName}}
    </ol>
    </div>
    <ng-tempate #emptyList>The users list is empty</ng-template>
    `,
  styles: []
})
export class DumbComponent implements OnInit {
    @Input() users : Object[];
  constructor() { }

  ngOnInit() {
  }

}
