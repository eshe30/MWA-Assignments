import { Directive, HostListener } from '@angular/core';
import { WebDriverLogger } from 'blocking-proxy/built/lib/webdriver_logger';

@Directive({
  selector: '[appLoggable]'
})
export class LoggableDirective {

  constructor() { }
  @HostListener('dblclick') logger(){
    console.log('DIV element has been clicked');
  }

}
