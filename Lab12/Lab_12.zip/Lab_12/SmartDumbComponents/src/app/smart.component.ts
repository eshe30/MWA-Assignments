import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smart',
  template: `
    <p>
      smart works!
    </p>
    <app-dumb [users]="data"></app-dumb>
  `,
  styles: []
})
export class SmartComponent implements OnInit {
  data = [{'firstName': 'eshe', 'lastName':'abebe'},
           {'firstName' : 'seble', 'lastName':'asefa'}];

  constructor() { }

  ngOnInit() {
  }

}
