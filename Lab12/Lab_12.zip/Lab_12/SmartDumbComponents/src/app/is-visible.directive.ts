import { Directive, Input, HostBinding, OnChanges } from '@angular/core';

@Directive({
  selector: '[appIsVisible]'
})
export class IsVisibleDirective {
  @Input() isVisible : boolean;
  constructor() { }
 @HostBinding('style.visibility') eleVisibility;

 ngOnChanges(){
   this.eleVisibility =!this.isVisible ? "hidden" : "none";
 }
}
